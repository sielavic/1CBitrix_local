<?
$MESS["T_EXAM_MENU_TITLE"] = "Навигация";
?>